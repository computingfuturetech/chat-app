from django.contrib import admin
from .models import ChatRoom, ChatMessage

@admin.register(ChatRoom)
class ChatRoomAdmin(admin.ModelAdmin):
    list_display = ['chat_room_id','chat_type', 'member_count']
    filter_horizontal = ['members']  

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ['chat', 'user', 'message', 'audio_file','video','document','image', 'timestamp', 'datestamp']
